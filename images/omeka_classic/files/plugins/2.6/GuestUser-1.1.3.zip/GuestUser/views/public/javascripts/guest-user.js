jQuery('document').ready(function() {
    var adminBarHeight = jQuery('#admin-bar');
    jQuery('#guest-user-register-info').css('top', adminBarHeight + 'px');
});