<?php
// Render CSV of the item and its associated annotations
printCsvExport(CsvExport_ItemAttachUtil::getThisAndAnnotations($item));
