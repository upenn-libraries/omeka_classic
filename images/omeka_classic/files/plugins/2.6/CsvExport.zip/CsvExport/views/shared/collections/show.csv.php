<?php
// Recursively find all items and print CSV of them
printCsvExport(CsvExport_CollectionAttachUtil::getSubitems($collection));
