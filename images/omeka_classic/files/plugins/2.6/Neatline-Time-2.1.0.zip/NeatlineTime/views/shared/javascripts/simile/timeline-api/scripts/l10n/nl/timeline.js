/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["nl"] = {
    wikiLinkLabel:  "Discussieer"
};

