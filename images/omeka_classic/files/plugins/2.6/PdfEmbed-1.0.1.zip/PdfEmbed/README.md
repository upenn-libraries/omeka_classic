# PDF Embed #
## A plugin for Omeka ##

This is a simple plugin that uses either the browser's built-in or
plugin-added PDF display capabilities or Mozilla's [PDF.js][1] to embed
PDFs on item and file pages.

 [1]: http://mozilla.github.io/pdf.js/
