All images in this folder will be displayed in the carousel on the home page.
