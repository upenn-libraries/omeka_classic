# HTML5 Media #
## A plugin for Omeka ##

This is a simple plugin that uses John Dyer's [MediaElement.js][1] to enable
cross-browser HTML5 `<video>` and `<audio>` players for Omeka files.

 [1]: http://mediaelementjs.com/
