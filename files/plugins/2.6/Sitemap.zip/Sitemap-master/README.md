# Sitemap
Adds a dynamic xml sitemap showing the public navigation tree, for SEO purposes

If you use this plugin, please take a moment to submit feedback about your experience, so we can keep making Omeka better: [User Survey](https://docs.google.com/forms/d/1ejuJ0OsAAIKDoylTI3pezZfDGoxKx1sNi_E4fgVgDjg/viewform?usp=send_form "User Survey")
