<?php

class RecordRelationsVocabulary extends Omeka_Record_AbstractRecord
{
    public $id;
    public $name;
    public $description;
    public $namespace_prefix;
    public $namespace_uri;
    public $custom;
}