# Description
A text annotation plugin for Omeka that uses hypothes.is (https://hypothes.is/). 

# Notes
Logging into your hypothes.is account requires third-party cookies. If you have third-party cookies blocked in your browser, you will need to change that setting.
