<?php

class EditorialExhibitAccess extends Omeka_Record_AbstractRecord
{
    public $user_id;

    public $exhibit_id;

    public $block_id;
}
