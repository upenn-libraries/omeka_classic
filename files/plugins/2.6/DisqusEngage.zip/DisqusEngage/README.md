# Description
An Omeka plugin that adds Disqus Engage comments to items and collections pages. A Disqus account is required. Moderate comments and change account settings at [disqus.com](https://disqus.com).
