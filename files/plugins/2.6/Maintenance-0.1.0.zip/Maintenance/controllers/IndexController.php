<?php

class Maintenance_IndexController extends Omeka_Controller_AbstractActionController
{
    public function indexAction()
    {
    }
}
