<?php echo head(array('bodyid'=>'home')); ?>

<p>Omeka is currently under maintenance.</p>

<?php echo foot(); ?>
