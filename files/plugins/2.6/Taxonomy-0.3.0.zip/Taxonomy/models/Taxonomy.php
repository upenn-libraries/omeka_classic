<?php

class Taxonomy extends Omeka_Record_AbstractRecord
{
    public $id;
    public $name;
}
