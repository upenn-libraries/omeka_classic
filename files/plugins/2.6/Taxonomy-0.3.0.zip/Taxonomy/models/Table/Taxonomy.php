<?php

class Table_Taxonomy extends Omeka_Db_Table {}
