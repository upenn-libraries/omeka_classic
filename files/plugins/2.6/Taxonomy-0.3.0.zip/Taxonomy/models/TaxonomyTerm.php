<?php

class TaxonomyTerm extends Omeka_Record_AbstractRecord
{
    public $id;
    public $taxonomy_id;
    public $code;
    public $value;
}
