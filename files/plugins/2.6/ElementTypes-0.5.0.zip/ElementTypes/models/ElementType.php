<?php

class ElementType extends Omeka_Record_AbstractRecord
{
    public $id;
    public $element_id;
    public $element_type;
    public $element_type_options;
}
