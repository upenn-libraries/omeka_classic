ItemReview
==========

Gives Omeka administrators the ability to mark all items created by certain user roles for administrative review before publication.

If you use this plugin, please take a moment to submit feedback about your experience, so we can keep making Omeka better: [User Survey](https://docs.google.com/forms/d/1Qt2SQEOFMa9B46ej48WoOUjXWkSwqKCcrn7vH8Oiwmw/viewform?usp=send_form "User Survey")
