<?php
/**
 * Item Review
 *
 * This Omeka 2.0+ plugin allows administrators the option to require curatrial review for bulk imported items (or all items) before they can be made public.
 * 
 *
 * @copyright Copyright 2014 UCSC Library Digital Initiatives
 * @license http://www.gnu.org/licenses/gpl-3.0.txt GNU GPLv3
 *
 * @package ItemReview
 */

?>

