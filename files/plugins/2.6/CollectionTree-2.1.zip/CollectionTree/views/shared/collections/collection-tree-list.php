<h2><?php echo __('Collection Tree'); ?></h2>
<div id="collection-tree">
<?php echo $this->collectionTreeList($collection_tree); ?>
</div>
